import { Header } from "@/components/header"
import { CreateGameForm } from "@/components/create-game-form"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"

export default async function CreatePage() {
  const supabase = await createClient()

  if (!supabase) {
    return (
      <div className="min-h-screen relative">
        <div className="fixed inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: "url(/placeholder.svg?height=1080&width=1920&query=Sports+Background)",
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundAttachment: "fixed",
            }}
          />
          <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
        </div>
        <Header />
        <main className="container mx-auto px-4 py-8 sm:py-12">
          <div className="max-w-2xl mx-auto">
            <Card className="border-destructive/50 bg-destructive/10">
              <CardContent className="pt-6 flex items-center gap-4">
                <AlertCircle className="h-8 w-8 text-destructive" />
                <div>
                  <h2 className="text-lg font-semibold text-destructive">Configuration Required</h2>
                  <p className="text-muted-foreground">
                    Please configure Supabase environment variables to create games.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login?redirect=/create")
  }

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: "url(/sports-bg.jpg)",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8 sm:mb-10">
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Create a Game</h1>
            <p className="text-muted-foreground text-base sm:text-lg">
              Set up your game in seconds with our quick-select options
            </p>
          </div>
          <CreateGameForm />
        </div>
      </main>
    </div>
  )
}
