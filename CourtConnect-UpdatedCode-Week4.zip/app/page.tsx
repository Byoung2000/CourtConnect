import { createClient } from "@/lib/supabase/server"
import { GamesList } from "@/components/games-list"
import { Header } from "@/components/header"
import type { Game } from "@/lib/types"

export const dynamic = "force-dynamic"

async function getGames(): Promise<Game[]> {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return []
    }

    const { data, error } = await supabase
      .from("games")
      .select("*")
      .gte("date", new Date().toISOString().split("T")[0])
      .order("date", { ascending: true })
      .order("start_time", { ascending: true })

    if (error) {
      console.error("[v0] Error fetching games:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("[v0] Failed to fetch games:", error)
    return []
  }
}

async function getSignupCounts(): Promise<Record<string, number>> {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return {}
    }

    const { data, error } = await supabase.from("signups").select("game_id")

    if (error) {
      console.error("[v0] Error fetching signups:", error)
      return {}
    }

    const counts: Record<string, number> = {}
    data?.forEach((signup) => {
      counts[signup.game_id] = (counts[signup.game_id] || 0) + 1
    })

    return counts
  } catch (error) {
    console.error("[v0] Failed to fetch signup counts:", error)
    return {}
  }
}

export default async function Home() {
  const [games, signupCounts] = await Promise.all([getGames(), getSignupCounts()])

  const gamesWithSpots = games.map((game) => ({
    ...game,
    spots_left: game.max_players - (signupCounts[game.id] || 0),
  }))

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: "url(/placeholder.svg?height=1080&width=1920&query=sports%20background)",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8 sm:mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Find Your Game</h1>
          <p className="text-muted-foreground text-base sm:text-lg">
            Browse available pickup games and join your community
          </p>
        </div>
        <GamesList games={gamesWithSpots} />
      </main>
    </div>
  )
}
