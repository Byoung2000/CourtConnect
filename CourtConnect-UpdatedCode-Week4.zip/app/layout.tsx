import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], display: "swap" })

export const metadata: Metadata = {
  title: "CourtConnect - Find Pickup Games",
  description: "Find, create, and join pickup sports games on campus",
  generator: "v0.app",
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  },
  formatDetection: {
    telephone: false,
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "CourtConnect",
  },
  icons: {
    icon: [
      {
        url: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40' fill='none'><rect x='4' y='4' width='32' height='32' rx='8' stroke='%23FF6B00' strokeWidth='2.5'/><line x1='4' y1='20' x2='36' y2='20' stroke='%23FF6B00' strokeWidth='2' strokeDasharray='4 2'/><circle cx='20' cy='20' r='5' stroke='%23FF6B00' strokeWidth='2' fill='none'/><path d='M14 4V10C14 13.3137 16.6863 16 20 16C23.3137 16 26 13.3137 26 10V4' stroke='%23FF6B00' strokeWidth='2'/><rect x='15' y='30' width='10' height='6' stroke='%23FF6B00' strokeWidth='2'/><line x1='20' y1='20' x2='20' y2='30' stroke='%23FF6B00' strokeWidth='1.5'/><circle cx='20' cy='20' r='2' fill='%235B21B6'/></svg>",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  },
  manifest: "/manifest.json",
  themeColor: "#FF6B00",
  openGraph: {
    title: "CourtConnect",
    description: "Find, create, and join pickup sports games",
    type: "website",
    siteName: "CourtConnect",
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "white" },
    { media: "(prefers-color-scheme: dark)", color: "#000000" },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://nominatim.openstreetmap.org" />
        <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com" />
        {/* Prefetch Leaflet for map functionality */}
        <link rel="prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
        <link rel="prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js" />
      </head>
      <body className={`${inter.className} antialiased`}>
        <div className="min-h-screen w-full overflow-x-hidden sports-bg">{children}</div>
      </body>
    </html>
  )
}
