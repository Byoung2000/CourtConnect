import { createClient } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Bell } from "lucide-react"
import type { Notification } from "@/lib/types"

export const dynamic = "force-dynamic"

// Note: In a real app with auth, you'd get the user ID from the session
// For now, this is a placeholder structure
async function getNotifications(userId: string): Promise<Notification[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("[v0] Error fetching notifications:", error)
    return []
  }

  return data || []
}

export default async function NotificationsPage() {
  // Placeholder user ID - replace with actual auth in production
  const userId = "demo-user"
  const notifications = await getNotifications(userId)

  const unreadNotifications = notifications.filter((n) => !n.read)
  const readNotifications = notifications.filter((n) => n.read)

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "new_game":
        return "bg-primary/10"
      case "player_joined":
        return "bg-accent/10"
      case "game_updated":
        return "bg-secondary/10"
      case "game_canceled":
        return "bg-destructive/10"
      default:
        return "bg-muted"
    }
  }

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "new_game":
        return <Badge className="bg-primary/20 text-primary border-primary/30">New Game</Badge>
      case "player_joined":
        return <Badge className="bg-accent/20 text-accent border-accent/30">Player Joined</Badge>
      case "game_updated":
        return <Badge className="bg-secondary/20 text-secondary border-secondary/30">Updated</Badge>
      case "game_canceled":
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30">Canceled</Badge>
      default:
        return <Badge variant="outline">Notification</Badge>
    }
  }

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12 max-w-3xl">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Bell className="w-6 h-6 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">Notifications</h1>
          </div>
          <p className="text-muted-foreground">Stay updated on games and player activity</p>
        </div>

        {/* Unread Notifications */}
        {unreadNotifications.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-4">Unread</h2>
            <div className="space-y-3">
              {unreadNotifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`border-l-4 ${getNotificationColor(notification.type)} border-border/50 bg-card/50 backdrop-blur`}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-foreground">{notification.title}</h3>
                          {getTypeBadge(notification.type)}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                        <p className="text-xs text-muted-foreground/70">
                          {new Date(notification.created_at).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            hour: "numeric",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                      <Link href={`/game/${notification.game_id}`} className="flex-shrink-0">
                        <Button size="sm" className="bg-primary hover:bg-primary/90">
                          View Game
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Read Notifications */}
        {readNotifications.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 opacity-60">Archive</h2>
            <div className="space-y-2">
              {readNotifications.map((notification) => (
                <Card
                  key={notification.id}
                  className="border-border/50 bg-card/30 backdrop-blur opacity-70 hover:opacity-100 transition-opacity"
                >
                  <CardContent className="pt-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium text-sm text-foreground">{notification.title}</h3>
                          {getTypeBadge(notification.type)}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1">{notification.message}</p>
                      </div>
                      <Link href={`/game/${notification.game_id}`} className="flex-shrink-0">
                        <Button variant="outline" size="sm" className="border-border/50 bg-transparent">
                          View
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {notifications.length === 0 && (
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardContent className="pt-12 pb-12 text-center">
              <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No notifications yet</h3>
              <p className="text-muted-foreground mb-6">Create or join games to start receiving notifications</p>
              <Link href="/">
                <Button className="bg-primary hover:bg-primary/90">Browse Games</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
