"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import type { Game } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Shield, Trash2, Loader2, Info, Copy, Check, Edit2, Save, X } from "lucide-react"

interface HostControlsProps {
  game: Game
}

export function HostControls({ game }: HostControlsProps) {
  const router = useRouter()
  const [isDeleting, setIsDeleting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Edit form state
  const [editNote, setEditNote] = useState(game.note || "")
  const [editMaxPlayers, setEditMaxPlayers] = useState(game.max_players.toString())

  const handleCopyPin = async () => {
    try {
      await navigator.clipboard.writeText(game.host_pin)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("[v0] Error copying PIN:", err)
    }
  }

  const handleDeleteGame = async () => {
    setIsDeleting(true)
    setError(null)

    try {
      const supabase = createClient()

      // Delete all signups first (cascade)
      const { error: signupsError } = await supabase.from("signups").delete().eq("game_id", game.id)

      if (signupsError) {
        console.error("[v0] Error deleting signups:", signupsError)
        throw signupsError
      }

      // Delete all messages for the game
      const { error: messagesError } = await supabase.from("messages").delete().eq("game_id", game.id)

      if (messagesError) {
        console.error("[v0] Error deleting messages:", messagesError)
        throw messagesError
      }

      // Finally, delete the game itself
      const { error: gameError } = await supabase.from("games").delete().eq("id", game.id)

      if (gameError) {
        console.error("[v0] Error deleting game:", gameError)
        throw gameError
      }

      // Clear host PIN from localStorage
      localStorage.removeItem(`host_pin_${game.id}`)

      // Redirect and trigger page refresh to show updates everywhere
      router.push("/")
      router.refresh()
    } catch (err) {
      console.error("[v0] Error during game deletion:", err)
      setError(err instanceof Error ? err.message : "Failed to delete game")
      setIsDeleting(false)
    }
  }

  const handleSaveChanges = async () => {
    setIsSaving(true)
    setError(null)
    setSuccess(null)

    try {
      const supabase = createClient()

      const { error: updateError } = await supabase
        .from("games")
        .update({
          note: editNote,
          max_players: Number.parseInt(editMaxPlayers),
          updated_at: new Date().toISOString(),
        })
        .eq("id", game.id)
        .eq("host_pin", game.host_pin)

      if (updateError) throw updateError

      setSuccess("Game updated successfully!")
      setIsEditing(false)
      router.refresh()
    } catch (err) {
      console.error("[v0] Error updating game:", err)
      setError(err instanceof Error ? err.message : "Failed to update game")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card className="border-border bg-card border-primary/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <CardTitle className="text-xl text-foreground">Host Controls</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-accent/50 bg-accent/10">
              <AlertDescription className="text-accent">{success}</AlertDescription>
            </Alert>
          )}

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs sm:text-sm">
              As the host, you can edit game details, manage players, and delete the game. Deleted games are permanently
              removed.
            </AlertDescription>
          </Alert>

          {/* Host PIN */}
          <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
            <p className="text-xs sm:text-sm text-muted-foreground mb-2">Host PIN</p>
            <div className="flex items-center gap-2">
              <p className="font-mono font-semibold text-foreground flex-1">{game.host_pin}</p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopyPin}
                className="border-border/50 h-8 w-8 p-0 bg-transparent"
              >
                {copied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Save this PIN to manage your game from other devices</p>
          </div>

          {/* Edit Game Details */}
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} variant="outline" className="w-full border-border/50 gap-2">
              <Edit2 className="w-4 h-4" />
              Edit Game Details
            </Button>
          ) : (
            <div className="space-y-3 p-3 rounded-lg bg-muted/30 border border-border/50">
              <div className="space-y-2">
                <Label htmlFor="maxPlayers" className="text-xs sm:text-sm font-semibold">
                  Max Players
                </Label>
                <Input
                  id="maxPlayers"
                  type="number"
                  min="1"
                  max="50"
                  value={editMaxPlayers}
                  onChange={(e) => setEditMaxPlayers(e.target.value)}
                  className="bg-background/50 border-border/50 h-9 text-sm"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="note" className="text-xs sm:text-sm font-semibold">
                  Notes / Description
                </Label>
                <Textarea
                  id="note"
                  value={editNote}
                  onChange={(e) => setEditNote(e.target.value)}
                  placeholder="Add any special instructions or details..."
                  className="bg-background/50 border-border/50 resize-none text-sm"
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleSaveChanges}
                  disabled={isSaving}
                  className="flex-1 bg-primary hover:bg-primary/90 h-9 text-sm gap-2"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      Save
                    </>
                  )}
                </Button>
                <Button
                  onClick={() => {
                    setIsEditing(false)
                    setEditNote(game.note || "")
                    setEditMaxPlayers(game.max_players.toString())
                  }}
                  variant="outline"
                  className="border-border/50 h-9 text-sm gap-2"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </Button>
              </div>
            </div>
          )}

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full" disabled={isDeleting || isEditing}>
                {isDeleting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Game Permanently
                  </>
                )}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Game Permanently?</AlertDialogTitle>
                <AlertDialogDescription className="space-y-2">
                  <p>This will:</p>
                  <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                    <li>Remove this game from everywhere (all user dashboards)</li>
                    <li>Notify all participants</li>
                    <li>Delete all chat messages</li>
                    <li>Permanently erase all data from the database</li>
                  </ul>
                  <p className="font-semibold text-destructive mt-3">This action cannot be undone.</p>
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteGame}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete Game
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>

      {/* Quick Stats Card */}
      <Card className="border-border bg-card/50 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-foreground">Game Stats</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between items-center p-2 rounded bg-muted/30">
            <span className="text-xs text-muted-foreground">Created</span>
            <span className="text-xs font-medium text-foreground">
              {new Date(game.created_at).toLocaleDateString()}
            </span>
          </div>
          <div className="flex justify-between items-center p-2 rounded bg-muted/30">
            <span className="text-xs text-muted-foreground">Sport</span>
            <span className="text-xs font-medium text-foreground">{game.sport}</span>
          </div>
          <div className="flex justify-between items-center p-2 rounded bg-muted/30">
            <span className="text-xs text-muted-foreground">Status</span>
            <span className="text-xs font-medium text-accent">Active</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
