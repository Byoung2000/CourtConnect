"use client"

import { Button } from "@/components/ui/button"
import type { ReactNode } from "react"

interface MobileOptimizedButtonProps {
  children: ReactNode
  onClick?: () => void
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  className?: string
  disabled?: boolean
  type?: "button" | "submit" | "reset"
}

export function MobileOptimizedButton({
  children,
  onClick,
  variant = "default",
  className = "",
  disabled = false,
  type = "button",
}: MobileOptimizedButtonProps) {
  return (
    <Button
      onClick={onClick}
      variant={variant}
      className={`
        h-12 text-base sm:h-10 sm:text-sm
        min-w-[44px] px-4
        active:scale-95 transition-transform
        touch-manipulation
        ${className}
      `}
      disabled={disabled}
      type={type}
    >
      {children}
    </Button>
  )
}
