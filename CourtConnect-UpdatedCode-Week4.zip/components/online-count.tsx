"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

export function OnlineCount() {
  const [count, setCount] = useState(1) // Default to 1 (you)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const supabase = createClient()
    if (!supabase) return

    const channel = supabase.channel("online-users")

    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState()
        // Determine user count based on unique presence keys
        const userCount = Object.keys(state).length
        setCount(Math.max(1, userCount))
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ online_at: new Date().toISOString() })
        }
      })

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  if (!mounted) return null

  return (
    <div className="flex items-center gap-2 bg-secondary/50 px-3 py-1.5 rounded-full border border-border/50 backdrop-blur-sm shadow-sm animate-in fade-in zoom-in duration-300">
      <span className="relative flex h-2.5 w-2.5">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
      </span>
      <span className="text-xs font-semibold text-foreground/90">{count} Live</span>
    </div>
  )
}
