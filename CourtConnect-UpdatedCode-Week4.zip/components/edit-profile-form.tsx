"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Profile } from "@/lib/types"

interface EditProfileFormProps {
  userId: string
  onSuccess: () => void
}

const SPORTS = ["Basketball", "Football", "Soccer", "Tennis", "Volleyball", "Baseball", "Badminton"]

export function EditProfileForm({ userId, onSuccess }: EditProfileFormProps) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Form state
  const [name, setName] = useState("")
  const [bio, setBio] = useState("")
  const [favoriteSport, setFavoriteSport] = useState("")

  useEffect(() => {
    async function fetchProfile() {
      try {
        const supabase = createClient()
        const { data, error: fetchError } = await supabase.from("profiles").select("*").eq("id", userId).single()

        if (fetchError) {
          throw new Error(fetchError.message)
        }

        setProfile(data)
        setName(data.name || "")
        setBio(data.bio || "")
        setFavoriteSport(data.favorite_sport || "")
      } catch (err) {
        console.error("[v0] Error fetching profile:", err)
        setError("Failed to load profile")
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [userId])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    try {
      const supabase = createClient()
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          name,
          bio,
          favorite_sport: favoriteSport,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) {
        throw new Error(updateError.message)
      }

      onSuccess()
    } catch (err) {
      console.error("[v0] Error updating profile:", err)
      setError(err instanceof Error ? err.message : "Failed to update profile")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardContent className="pt-6">
          <p className="text-muted-foreground">Loading profile...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur">
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
              {error}
            </div>
          )}

          {/* Name Field */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground font-semibold">
              Name
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              required
              className="bg-background/50 border-border/50"
            />
          </div>

          {/* Bio Field */}
          <div className="space-y-2">
            <Label htmlFor="bio" className="text-foreground font-semibold">
              Bio
            </Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us about yourself..."
              className="bg-background/50 border-border/50 resize-none"
              rows={4}
            />
          </div>

          {/* Favorite Sport */}
          <div className="space-y-2">
            <Label htmlFor="sport" className="text-foreground font-semibold">
              Favorite Sport
            </Label>
            <Select value={favoriteSport} onValueChange={setFavoriteSport}>
              <SelectTrigger className="bg-background/50 border-border/50">
                <SelectValue placeholder="Select your favorite sport" />
              </SelectTrigger>
              <SelectContent>
                {SPORTS.map((sport) => (
                  <SelectItem key={sport} value={sport}>
                    {sport}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            <Button type="submit" disabled={submitting} className="flex-1 bg-primary hover:bg-primary/90">
              {submitting ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
