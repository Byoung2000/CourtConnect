"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin } from "lucide-react"

interface GameMapProps {
  location: string
  latitude?: string
  longitude?: string
  title?: string
}

export function GameMap({ location, latitude, longitude, title = "Game Location" }: GameMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)

  useEffect(() => {
    if (!latitude || !longitude || !mapRef.current) return

    // Dynamically load Leaflet
    if (!window.L) {
      const link = document.createElement("link")
      link.rel = "stylesheet"
      link.href = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"
      document.head.appendChild(link)

      const script = document.createElement("script")
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"
      script.onload = () => {
        initializeMap()
      }
      document.body.appendChild(script)
    } else {
      initializeMap()
    }

    function initializeMap() {
      const lat = Number.parseFloat(latitude)
      const lon = Number.parseFloat(longitude)

      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
      }

      mapInstanceRef.current = window.L.map(mapRef.current).setView([lat, lon], 15)

      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(mapInstanceRef.current)

      window.L.marker([lat, lon]).addTo(mapInstanceRef.current).bindPopup(location).openPopup()
    }

    return () => {
      // Cleanup
    }
  }, [latitude, longitude, location])

  if (!latitude || !longitude) {
    return (
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            <MapPin className="w-5 h-5 mr-2" />
            <span>Location data not available</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur overflow-hidden">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div ref={mapRef} className="w-full h-64 rounded-lg border border-border/50 overflow-hidden" />
        <p className="text-sm text-muted-foreground mt-3">{location}</p>
      </CardContent>
    </Card>
  )
}
