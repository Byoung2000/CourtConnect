import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/logo"
import { createClient } from "@/lib/supabase/server"
import { UserMenu } from "@/components/user-menu"
import { OnlineCount } from "@/components/online-count"

export async function Header() {
  let user = null
  let profile = null

  try {
    const supabase = await createClient()

    if (!supabase) {
      // console.warn("Supabase client not available")
    } else {
      const {
        data: { user: authUser },
        error: userError,
      } = await supabase.auth.getUser()

      if (userError) {
        if (userError.message !== "Auth session missing!") {
          console.error("[v0] Error fetching user:", userError)
        }
      } else if (authUser) {
        user = authUser
        const { data, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .maybeSingle()

        if (profileError) {
          console.error("[v0] Error fetching profile:", profileError)
        } else {
          profile = data
        }
      }
    }
  } catch (error) {
    console.error("[v0] Error in Header component:", error)
  }

  return (
    <header className="border-b border-border bg-gradient-to-r from-card/80 to-card/60 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-3 sm:py-4">
        <div className="flex items-center justify-between">
          {/* Logo Section */}
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 sm:gap-3 hover:opacity-80 transition-opacity group">
              <Logo size="md" showText={true} />
            </Link>
            <div className="hidden sm:block">
              <OnlineCount />
            </div>
          </div>

          {/* Navigation and Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="sm:hidden">
              <OnlineCount />
            </div>
            {user && profile ? (
              <>
                <Link href="/create">
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 text-primary-foreground font-semibold text-xs sm:text-sm h-9 sm:h-10 px-3 sm:px-6 shadow-md hover:shadow-lg transition-all duration-200"
                  >
                    Create Game
                  </Button>
                </Link>
                <UserMenu user={user} profile={profile} />
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/auth/login">
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm h-9 sm:h-10 px-3 sm:px-4">
                    Log In
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 text-primary-foreground font-semibold text-xs sm:text-sm h-9 sm:h-10 px-3 sm:px-6 shadow-md hover:shadow-lg transition-all duration-200"
                  >
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
