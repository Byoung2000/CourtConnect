"use client"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function Logo({ size = "md", showText = true }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  }

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl",
  }

  return (
    <div className="flex items-center gap-2.5">
      <div className={`${sizeClasses[size]} relative flex items-center justify-center`}>
        <svg viewBox="0 0 40 40" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Omni-Court Design: Combining elements from multiple sports */}

          {/* 1. The Field/Court Boundary (All Sports) */}
          <rect x="4" y="4" width="32" height="32" rx="8" stroke="hsl(32 100% 55%)" strokeWidth="2.5" />

          {/* 2. Center Line (Tennis, Volleyball, Pickleball, Soccer, Basketball) */}
          <line x1="4" y1="20" x2="36" y2="20" stroke="hsl(32 100% 55%)" strokeWidth="2" strokeDasharray="4 2" />

          {/* 3. Center Circle (Soccer, Basketball) */}
          <circle cx="20" cy="20" r="5" stroke="hsl(32 100% 55%)" strokeWidth="2" fill="none" />

          {/* 4. Basketball Key / 3-point Arc (Top) */}
          <path
            d="M14 4V10C14 13.3137 16.6863 16 20 16C23.3137 16 26 13.3137 26 10V4"
            stroke="hsl(32 100% 55%)"
            strokeWidth="2"
          />

          {/* 5. Soccer/Football Goal Area (Bottom) */}
          <rect x="15" y="30" width="10" height="6" stroke="hsl(32 100% 55%)" strokeWidth="2" />

          {/* 6. Tennis/Pickleball Service Lines (Subtle touches) */}
          <line x1="20" y1="20" x2="20" y2="30" stroke="hsl(32 100% 55%)" strokeWidth="1.5" />

          {/* Accent Dot (The Ball/Puck) */}
          <circle cx="20" cy="20" r="2" fill="hsl(262 100% 35%)" />
        </svg>
      </div>

      {/* Wordmark */}
      {showText && (
        <div className="flex items-baseline leading-none tracking-tight">
          <span className={`font-bold text-primary ${textSizeClasses[size]}`}>Court</span>
          <span className={`font-semibold text-foreground ${textSizeClasses[size]}`}>Connect</span>
        </div>
      )}
    </div>
  )
}
