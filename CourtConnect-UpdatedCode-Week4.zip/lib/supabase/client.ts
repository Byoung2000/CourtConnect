import { createBrowserClient } from "@supabase/ssr"

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL || "https://ykondopbutrwviapvzdig.supabase.co"

const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlxa29uZGJwdXRyd2lhcHZ6ZGlnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3Mzg2ODcsImV4cCI6MjA3OTMxNDY4N30.fXdHAbnmQXxQIGNl_0Djd9WOTzc-0jLQTSPjkkoXzl8"

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("[Supabase] URL or anon key is missing in client")
}

export function createClient() {
  console.log("[Supabase] client init", {
    hasUrl: !!supabaseUrl,
    hasKey: !!supabaseAnonKey,
  })
  return createBrowserClient(supabaseUrl, supabaseAnonKey)
}
