export interface Game {
  id: string
  sport: string
  date: string
  start_time: string
  end_time: string
  location: string
  max_players: number
  note?: string
  host_name: string
  host_pin: string
  created_at: string
}

export interface Signup {
  id: string
  game_id: string
  player_name: string
  created_at: string
}

export interface Message {
  id: string
  game_id: string
  sender_name: string
  message_text: string
  created_at: string
}

export interface GameWithSignups extends Game {
  signups: Signup[]
  spots_left: number
}

export interface Profile {
  id: string
  username?: string
  email?: string
  name: string
  bio?: string
  favorite_sport?: string
  preferred_sports?: string[]
  skill_level?: "beginner" | "casual" | "competitive"
  games_hosted: number
  games_joined: number
  created_at: string
  updated_at: string
}

export interface Notification {
  id: string
  user_id: string
  game_id: string
  type: "new_game" | "game_updated" | "game_canceled" | "player_joined"
  title: string
  message: string
  read: boolean
  created_at: string
}
