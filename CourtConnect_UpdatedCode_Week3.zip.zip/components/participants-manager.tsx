"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Users, Trash2, AlertCircle } from "lucide-react"
import type { Game } from "@/lib/types"

interface ParticipantsManagerProps {
  game: Game
  participants: Array<{ id: string; name: string; email: string }>
}

export function ParticipantsManager({ game, participants }: ParticipantsManagerProps) {
  const [isRemoving, setIsRemoving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [localParticipants, setLocalParticipants] = useState(participants)

  const handleRemoveParticipant = async (participantId: string, participantName: string) => {
    setIsRemoving(true)
    setError(null)
    setSuccess(null)

    try {
      const supabase = createClient()

      const { error: deleteError } = await supabase.from("signups").delete().eq("id", participantId)

      if (deleteError) throw deleteError

      setLocalParticipants((prev) => prev.filter((p) => p.id !== participantId))
      setSuccess(`${participantName} has been removed from the game`)
    } catch (err) {
      console.error("[v0] Error removing participant:", err)
      setError(err instanceof Error ? err.message : "Failed to remove participant")
    } finally {
      setIsRemoving(false)
    }
  }

  return (
    <Card className="border-border bg-card border-secondary/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-secondary" />
          <CardTitle className="text-lg">
            Participants ({localParticipants.length}/{game.max_players})
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-accent/50 bg-accent/10">
            <AlertDescription className="text-accent">{success}</AlertDescription>
          </Alert>
        )}

        {localParticipants.length === 0 ? (
          <div className="text-center py-8">
            <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-50" />
            <p className="text-muted-foreground">No participants yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {localParticipants.map((participant) => (
              <div
                key={participant.id}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-primary/20 text-primary text-xs font-semibold">
                      {participant.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground">{participant.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{participant.email}</p>
                  </div>
                </div>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                      disabled={isRemoving}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove Participant?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to remove {participant.name} from this game? They will be notified.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Keep</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => handleRemoveParticipant(participant.id, participant.name)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            ))}
          </div>
        )}

        {localParticipants.length < game.max_players && (
          <div className="p-3 rounded-lg bg-accent/10 border border-accent/30">
            <p className="text-xs text-accent font-medium">
              {game.max_players - localParticipants.length} spot
              {game.max_players - localParticipants.length !== 1 ? "s" : ""} available
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
