"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { MapPin, Loader2, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"

interface LocationSuggestion {
  name: string
  display_name: string
  lat: string
  lon: string
  type: string
}

interface LocationSearchProps {
  onSelect: (location: string, lat?: string, lon?: string) => void
  value: string
  placeholder?: string
}

export function LocationSearch({ onSelect, value, placeholder = "Search for a location..." }: LocationSearchProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [query, setQuery] = useState(value)
  const debounceTimer = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    setQuery(value)
  }, [value])

  const searchLocations = async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setSuggestions([])
      return
    }

    setIsLoading(true)
    try {
      // Using Nominatim API (free, no key required)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=5&dedupe=1`,
      )
      const data = await response.json()
      setSuggestions(data as LocationSuggestion[])
      setIsOpen(true)
    } catch (err) {
      console.error("[v0] Error searching locations:", err)
      setSuggestions([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuery = e.target.value
    setQuery(newQuery)

    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current)
    }

    debounceTimer.current = setTimeout(() => {
      searchLocations(newQuery)
    }, 300)
  }

  const handleSelect = (suggestion: LocationSuggestion) => {
    onSelect(suggestion.name || suggestion.display_name, suggestion.lat, suggestion.lon)
    setQuery(suggestion.name || suggestion.display_name)
    setSuggestions([])
    setIsOpen(false)
  }

  const handleClear = () => {
    setQuery("")
    setSuggestions([])
    onSelect("")
  }

  return (
    <div className="relative">
      <div className="relative flex items-center">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
        <Input
          type="text"
          value={query}
          onChange={handleChange}
          onFocus={() => suggestions.length > 0 && setIsOpen(true)}
          onBlur={() => setTimeout(() => setIsOpen(false), 200)}
          placeholder={placeholder}
          className="pl-10 bg-background h-12 text-base"
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
        {isLoading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground animate-spin" />
        )}
      </div>

      {isOpen && suggestions.length > 0 && (
        <Card className="absolute top-14 left-0 right-0 border-border/50 bg-card shadow-lg z-50 max-h-64 overflow-y-auto">
          <div className="divide-y divide-border/50">
            {suggestions.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(suggestion)}
                className="w-full px-4 py-3 text-left hover:bg-muted/50 transition-colors text-sm"
              >
                <div className="font-medium text-foreground">{suggestion.name}</div>
                <div className="text-xs text-muted-foreground line-clamp-1">{suggestion.display_name}</div>
              </button>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
