"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import type { Message } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MessageCircle, Send, Loader2 } from "lucide-react"

interface LobbyChatProps {
  gameId: string
  playerName: string
}

export function LobbyChat({ gameId, playerName }: LobbyChatProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isSending, setIsSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Fetch initial messages
  useEffect(() => {
    const fetchMessages = async () => {
      const supabase = createClient()

      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("game_id", gameId)
        .order("created_at", { ascending: true })
        .limit(50)

      if (error) {
        console.error("[v0] Error fetching messages:", error)
        return
      }

      if (data) {
        setMessages(data)
      }
    }

    fetchMessages()
  }, [gameId])

  // Real-time subscription for new messages
  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(`game_${gameId}_messages`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `game_id=eq.${gameId}`,
        },
        (payload) => {
          const newMsg = payload.new as Message
          setMessages((prev) => [...prev, newMsg])
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [gameId])

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    setIsSending(true)
    setError(null)

    try {
      const supabase = createClient()

      const { error: insertError } = await supabase.from("messages").insert({
        game_id: gameId,
        sender_name: playerName,
        message_text: newMessage.trim(),
      })

      if (insertError) throw insertError

      setNewMessage("")
    } catch (err) {
      console.error("[v0] Error sending message:", err)
      setError(err instanceof Error ? err.message : "Failed to send message")
    } finally {
      setIsSending(false)
    }
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <div className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-primary" />
          <div>
            <CardTitle className="text-xl text-foreground">Lobby Chat</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">Chat with other players who have joined this game</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Messages Area */}
        <ScrollArea
          className="h-[350px] sm:h-[400px] w-full rounded-lg border border-border bg-background p-3 sm:p-4"
          ref={scrollRef}
        >
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground text-sm text-center">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-3 sm:space-y-4">
              {messages.map((message) => {
                const isOwnMessage = message.sender_name === playerName

                return (
                  <div key={message.id} className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[85%] sm:max-w-[70%] rounded-lg p-3 ${
                        isOwnMessage ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                      }`}
                    >
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="font-semibold text-sm">{message.sender_name}</span>
                        <span
                          className={`text-xs ${isOwnMessage ? "text-primary-foreground/70" : "text-muted-foreground"}`}
                        >
                          {formatTime(message.created_at)}
                        </span>
                      </div>
                      <p className="text-sm break-words">{message.message_text}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </ScrollArea>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="bg-background flex-1 text-sm sm:text-base h-10 sm:h-11"
            disabled={isSending}
            maxLength={500}
          />
          <Button
            type="submit"
            size="icon"
            className="bg-primary hover:bg-primary/90 text-primary-foreground h-10 sm:h-11 w-10 sm:w-11"
            disabled={isSending || !newMessage.trim()}
          >
            {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
