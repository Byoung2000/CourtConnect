"use client"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function Logo({ size = "md", showText = true }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  }

  const textSizeClasses = {
    sm: "text-sm",
    md: "text-lg",
    lg: "text-2xl",
  }

  return (
    <div className="flex items-center gap-2">
      <div className={`${sizeClasses[size]} relative flex items-center justify-center`}>
        <svg viewBox="0 0 40 40" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="courtGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="hsl(32 100% 55%)" />
              <stop offset="100%" stopColor="hsl(262 100% 35%)" />
            </linearGradient>
          </defs>

          {/* Stylized court lines forming a dynamic shape */}
          {/* Vertical center line (motion element) */}
          <line x1="20" y1="8" x2="20" y2="32" stroke="hsl(32 100% 55%)" strokeWidth="2.5" strokeLinecap="round" />

          {/* Left court line */}
          <line x1="12" y1="12" x2="12" y2="28" stroke="url(#courtGradient)" strokeWidth="2" strokeLinecap="round" />

          {/* Right court line */}
          <line x1="28" y1="12" x2="28" y2="28" stroke="hsl(262 100% 35%)" strokeWidth="2" strokeLinecap="round" />

          {/* Top horizontal line */}
          <line x1="12" y1="12" x2="28" y2="12" stroke="hsl(32 100% 55%)" strokeWidth="2" strokeLinecap="round" />

          {/* Bottom horizontal line */}
          <line x1="12" y1="28" x2="28" y2="28" stroke="hsl(262 100% 35%)" strokeWidth="2" strokeLinecap="round" />

          {/* Center court line - creates the court rectangle */}
          <line
            x1="12"
            y1="20"
            x2="28"
            y2="20"
            stroke="hsl(142 76% 45%)"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.8"
          />

          {/* Motion accent - diagonal speed lines */}
          <line
            x1="32"
            y1="14"
            x2="36"
            y2="12"
            stroke="hsl(32 100% 55%)"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.6"
          />
          <line
            x1="32"
            y1="20"
            x2="36"
            y2="20"
            stroke="url(#courtGradient)"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.5"
          />
          <line
            x1="32"
            y1="26"
            x2="36"
            y2="28"
            stroke="hsl(262 100% 35%)"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.6"
          />

          {/* Corner accent dots for polish */}
          <circle cx="12" cy="12" r="1.2" fill="hsl(32 100% 55%)" />
          <circle cx="28" cy="12" r="1.2" fill="hsl(262 100% 35%)" />
          <circle cx="12" cy="28" r="1.2" fill="hsl(262 100% 35%)" />
          <circle cx="28" cy="28" r="1.2" fill="hsl(32 100% 55%)" />
        </svg>
      </div>

      {/* Wordmark */}
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`font-black text-primary ${textSizeClasses[size]}`}>Court</span>
          <span className={`font-black text-secondary ${textSizeClasses[size]}`}>Connect</span>
        </div>
      )}
    </div>
  )
}
