"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import type { Game } from "@/lib/types"
import { RotateCcw, Filter } from "lucide-react"

interface DiscoveryFiltersProps {
  games: (Game & { spots_left: number })[]
}

export function DiscoveryFilters({ games }: DiscoveryFiltersProps) {
  const [selectedSports, setSelectedSports] = useState<string[]>([])
  const [dateRange, setDateRange] = useState<[number, number]>([0, 7])
  const [minPlayers, setMinPlayers] = useState(0)
  const [locationSearch, setLocationSearch] = useState("")
  const [hasAvailableSpots, setHasAvailableSpots] = useState(false)

  // Extract unique sports
  const uniqueSports = useMemo(() => Array.from(new Set(games.map((g) => g.sport))).sort(), [games])

  // Get unique locations
  const uniqueLocations = useMemo(
    () =>
      Array.from(new Set(games.map((g) => g.location)))
        .sort()
        .slice(0, 10),
    [games],
  )

  const handleSportToggle = (sport: string) => {
    setSelectedSports((prev) => (prev.includes(sport) ? prev.filter((s) => s !== sport) : [...prev, sport]))
  }

  const handleReset = () => {
    setSelectedSports([])
    setDateRange([0, 7])
    setMinPlayers(0)
    setLocationSearch("")
    setHasAvailableSpots(false)
  }

  const activeFilters = selectedSports.length + (locationSearch ? 1 : 0) + (hasAvailableSpots ? 1 : 0)

  return (
    <div className="space-y-4">
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Filters</CardTitle>
            </div>
            {activeFilters > 0 && (
              <Badge variant="secondary" className="bg-primary/20 text-primary">
                {activeFilters}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Reset Button */}
          {activeFilters > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              className="w-full gap-2 border-border/50 bg-transparent"
            >
              <RotateCcw className="w-4 h-4" />
              Reset Filters
            </Button>
          )}

          {/* Sports Filter */}
          <div className="space-y-3">
            <Label className="font-semibold text-foreground">Sports</Label>
            <div className="space-y-2">
              {uniqueSports.map((sport) => (
                <div key={sport} className="flex items-center space-x-2">
                  <Checkbox
                    id={sport}
                    checked={selectedSports.includes(sport)}
                    onCheckedChange={() => handleSportToggle(sport)}
                  />
                  <Label htmlFor={sport} className="font-normal cursor-pointer text-foreground">
                    {sport}
                  </Label>
                  <span className="text-xs text-muted-foreground ml-auto">
                    ({games.filter((g) => g.sport === sport).length})
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Location Filter */}
          <div className="space-y-3">
            <Label htmlFor="location" className="font-semibold text-foreground">
              Location
            </Label>
            <Input
              id="location"
              placeholder="Search locations..."
              value={locationSearch}
              onChange={(e) => setLocationSearch(e.target.value)}
              className="bg-background/50 border-border/50 h-9"
            />
            {locationSearch && uniqueLocations.length > 0 && (
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {uniqueLocations
                  .filter((loc) => loc.toLowerCase().includes(locationSearch.toLowerCase()))
                  .map((location) => (
                    <div
                      key={location}
                      className="px-3 py-2 rounded-md hover:bg-accent/10 cursor-pointer text-sm text-foreground transition-colors"
                      onClick={() => setLocationSearch(location)}
                    >
                      {location}
                    </div>
                  ))}
              </div>
            )}
          </div>

          {/* Availability Filter */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="available"
              checked={hasAvailableSpots}
              onCheckedChange={(checked) => setHasAvailableSpots(checked as boolean)}
            />
            <Label htmlFor="available" className="font-normal cursor-pointer text-foreground">
              Only available spots
            </Label>
          </div>

          {/* Date Range Info */}
          <div className="p-3 rounded-lg bg-muted/50 border border-border/30">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Date Range</p>
            <Slider value={dateRange} onValueChange={setDateRange} min={0} max={30} step={1} className="w-full" />
            <p className="text-xs text-muted-foreground mt-2">Next {dateRange[1]} days</p>
          </div>
        </CardContent>
      </Card>

      {/* Filter Summary */}
      {activeFilters > 0 && (
        <Card className="border-border/50 bg-primary/5 backdrop-blur">
          <CardContent className="pt-4">
            <p className="text-xs text-muted-foreground mb-2">Active filters:</p>
            <div className="flex flex-wrap gap-2">
              {selectedSports.map((sport) => (
                <Badge
                  key={sport}
                  variant="secondary"
                  className="bg-primary/20 text-primary cursor-pointer hover:bg-primary/30"
                  onClick={() => handleSportToggle(sport)}
                >
                  {sport} ×
                </Badge>
              ))}
              {locationSearch && (
                <Badge
                  variant="secondary"
                  className="bg-primary/20 text-primary cursor-pointer hover:bg-primary/30"
                  onClick={() => setLocationSearch("")}
                >
                  {locationSearch} ×
                </Badge>
              )}
              {hasAvailableSpots && (
                <Badge
                  variant="secondary"
                  className="bg-primary/20 text-primary cursor-pointer hover:bg-primary/30"
                  onClick={() => setHasAvailableSpots(false)}
                >
                  Available only ×
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
