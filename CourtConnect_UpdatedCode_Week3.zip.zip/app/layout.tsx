import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], display: "swap" })

export const metadata: Metadata = {
  title: "CourtConnect - Find Pickup Games",
  description: "Find, create, and join pickup sports games on campus",
  generator: "v0.app",
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  },
  formatDetection: {
    telephone: false,
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "CourtConnect",
  },
  icons: {
    icon: [
      {
        url: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'><circle cx='20' cy='20' r='20' fill='%23FF6B00'/><line x1='20' y1='8' x2='20' y2='32' stroke='%23fff' strokeWidth='2'/><line x1='12' y1='12' x2='12' y2='28' stroke='%23fff' strokeWidth='2'/><line x1='28' y1='12' x2='28' y2='28' stroke='%23fff' strokeWidth='2'/></svg>",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  },
  manifest: "/manifest.json",
  themeColor: "#FF6B00",
  openGraph: {
    title: "CourtConnect",
    description: "Find, create, and join pickup sports games",
    type: "website",
    siteName: "CourtConnect",
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "white" },
    { media: "(prefers-color-scheme: dark)", color: "#000000" },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://nominatim.openstreetmap.org" />
        <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com" />
        {/* Prefetch Leaflet for map functionality */}
        <link rel="prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
        <link rel="prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js" />
      </head>
      <body className={`${inter.className} antialiased`}>
        <div className="min-h-screen w-full overflow-x-hidden sports-bg">{children}</div>
      </body>
    </html>
  )
}
