"use client"
import { useRouter, useParams } from "next/navigation"
import { Header } from "@/components/header"
import { EditProfileForm } from "@/components/edit-profile-form"

export default function EditProfilePage() {
  const router = useRouter()
  const params = useParams()
  const id = params.id as string

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground">Edit Profile</h1>
          <p className="text-muted-foreground mt-2">Update your profile information</p>
        </div>
        <EditProfileForm userId={id} onSuccess={() => router.push(`/profile/${id}`)} />
      </main>
    </div>
  )
}
