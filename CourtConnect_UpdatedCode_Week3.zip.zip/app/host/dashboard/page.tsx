import { createClient } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Calendar, Users, MapPin, ClipboardList } from "lucide-react"
import type { Game } from "@/lib/types"

export const dynamic = "force-dynamic"

async function getHostedGames(): Promise<(Game & { signups: number })[]> {
  const supabase = await createClient()

  const { data: games, error: gamesError } = await supabase
    .from("games")
    .select("*")
    .gte("date", new Date().toISOString().split("T")[0])
    .order("date", { ascending: true })
    .order("start_time", { ascending: true })

  if (gamesError) {
    console.error("[v0] Error fetching games:", gamesError)
    return []
  }

  // Get signup counts for each game
  const { data: signups, error: signupsError } = await supabase.from("signups").select("game_id")

  if (signupsError) {
    console.error("[v0] Error fetching signups:", signupsError)
    return []
  }

  const signupCounts: Record<string, number> = {}
  signups?.forEach((signup) => {
    signupCounts[signup.game_id] = (signupCounts[signup.game_id] || 0) + 1
  })

  return (
    games?.map((game) => ({
      ...game,
      signups: signupCounts[game.id] || 0,
    })) || []
  )
}

export default async function HostDashboardPage() {
  const games = await getHostedGames()

  const upcomingGames = games.filter((g) => new Date(`${g.date}T${g.start_time}`) > new Date())
  const totalSignups = games.reduce((sum, g) => sum + g.signups, 0)

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Host Dashboard</h1>
          <p className="text-muted-foreground">Manage all your hosted games in one place</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground mb-1">Upcoming Games</p>
              <p className="text-3xl font-bold text-primary">{upcomingGames.length}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground mb-1">Total Players</p>
              <p className="text-3xl font-bold text-accent">{totalSignups}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground mb-1">Total Games</p>
              <p className="text-3xl font-bold text-secondary">{games.length}</p>
            </CardContent>
          </Card>
        </div>

        {/* Games List */}
        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Your Games</CardTitle>
            <CardDescription>Manage and monitor all your hosted games</CardDescription>
          </CardHeader>
          <CardContent>
            {games.length === 0 ? (
              <div className="text-center py-12">
                <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No games yet</h3>
                <p className="text-muted-foreground mb-6">Create your first game to get started</p>
                <Link href="/create">
                  <Button className="bg-primary hover:bg-primary/90">Create Game</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {games.map((game) => (
                  <Link key={game.id} href={`/game/${game.id}`}>
                    <div className="p-4 rounded-lg border border-border/50 hover:border-primary/50 hover:bg-card/80 transition-all cursor-pointer">
                      <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-foreground text-lg mb-2">{game.sport}</h3>
                          <div className="space-y-1 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4" />
                              {new Date(game.date).toLocaleDateString("en-US", {
                                weekday: "short",
                                month: "short",
                                day: "numeric",
                              })}
                              {" • "}
                              {game.start_time}
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4" />
                              {game.location}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <Users className="w-4 h-4 text-accent" />
                              <span className="font-semibold text-foreground">
                                {game.signups} / {game.max_players}
                              </span>
                            </div>
                            {game.signups >= game.max_players ? (
                              <Badge className="bg-destructive/20 text-destructive text-xs mt-1">Full</Badge>
                            ) : (
                              <Badge className="bg-accent/20 text-accent text-xs mt-1">
                                {game.max_players - game.signups} spots left
                              </Badge>
                            )}
                          </div>
                          <Button className="bg-primary hover:bg-primary/90 text-sm">View</Button>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
