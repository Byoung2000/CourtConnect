-- Create games table
CREATE TABLE IF NOT EXISTS public.games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sport TEXT NOT NULL,
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  location TEXT NOT NULL,
  max_players INTEGER NOT NULL,
  note TEXT,
  host_name TEXT NOT NULL,
  host_pin TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create signups table
CREATE TABLE IF NOT EXISTS public.signups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
  player_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
  sender_name TEXT NOT NULL,
  message_text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_games_date ON public.games(date);
CREATE INDEX IF NOT EXISTS idx_games_start_time ON public.games(start_time);
CREATE INDEX IF NOT EXISTS idx_signups_game_id ON public.signups(game_id);
CREATE INDEX IF NOT EXISTS idx_messages_game_id ON public.messages(game_id);

-- Enable Row Level Security (RLS) for public access
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.signups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access
CREATE POLICY "Enable read access for all users" ON public.games
  FOR SELECT USING (true);

CREATE POLICY "Enable read access for all users" ON public.signups
  FOR SELECT USING (true);

CREATE POLICY "Enable read access for all users" ON public.messages
  FOR SELECT USING (true);

-- Create policies for insert access (anyone can create)
CREATE POLICY "Enable insert for all users" ON public.games
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable insert for all users" ON public.signups
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable insert for all users" ON public.messages
  FOR INSERT WITH CHECK (true);
