-- Create games table
CREATE TABLE IF NOT EXISTS games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sport TEXT NOT NULL,
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  location TEXT NOT NULL,
  max_players INTEGER NOT NULL CHECK (max_players >= 2),
  note TEXT,
  host_name TEXT NOT NULL,
  host_pin TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create signups table
CREATE TABLE IF NOT EXISTS signups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  player_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(game_id, player_name)
);

-- Create messages table for lobby chat
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  sender_name TEXT NOT NULL,
  message_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE signups ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- RLS Policies for games (public read, anyone can create)
CREATE POLICY "games_select_all" ON games FOR SELECT USING (true);
CREATE POLICY "games_insert_all" ON games FOR INSERT WITH CHECK (true);
CREATE POLICY "games_update_own" ON games FOR UPDATE USING (host_pin = current_setting('app.host_pin', true));
CREATE POLICY "games_delete_own" ON games FOR DELETE USING (host_pin = current_setting('app.host_pin', true));

-- RLS Policies for signups (public read, anyone can join)
CREATE POLICY "signups_select_all" ON signups FOR SELECT USING (true);
CREATE POLICY "signups_insert_all" ON signups FOR INSERT WITH CHECK (true);
CREATE POLICY "signups_delete_all" ON signups FOR DELETE USING (true);

-- RLS Policies for messages (only joined players can see and send)
CREATE POLICY "messages_select_joined" ON messages 
  FOR SELECT 
  USING (
    game_id IN (
      SELECT game_id FROM signups WHERE player_name = current_setting('app.player_name', true)
    )
  );

CREATE POLICY "messages_insert_joined" ON messages 
  FOR INSERT 
  WITH CHECK (
    game_id IN (
      SELECT game_id FROM signups WHERE player_name = current_setting('app.player_name', true)
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_games_date ON games(date);
CREATE INDEX IF NOT EXISTS idx_games_sport ON games(sport);
CREATE INDEX IF NOT EXISTS idx_signups_game_id ON signups(game_id);
CREATE INDEX IF NOT EXISTS idx_messages_game_id ON messages(game_id);

-- Create a function to get spots left for a game
CREATE OR REPLACE FUNCTION get_spots_left(game_uuid UUID)
RETURNS INTEGER AS $$
DECLARE
  max_p INTEGER;
  current_signups INTEGER;
BEGIN
  SELECT max_players INTO max_p FROM games WHERE id = game_uuid;
  SELECT COUNT(*) INTO current_signups FROM signups WHERE game_id = game_uuid;
  RETURN max_p - current_signups;
END;
$$ LANGUAGE plpgsql;
