-- Create profiles table for user information
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  bio TEXT,
  favorite_sport TEXT,
  games_hosted INTEGER DEFAULT 0,
  games_joined INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  game_id UUID REFERENCES games(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- 'new_game', 'game_updated', 'game_canceled', 'player_joined'
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add new columns to games table for enhanced functionality
ALTER TABLE games ADD COLUMN IF NOT EXISTS host_id UUID REFERENCES profiles(id);
ALTER TABLE games ADD COLUMN IF NOT EXISTS is_canceled BOOLEAN DEFAULT FALSE;
ALTER TABLE games ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Add user_id to signups for better tracking
ALTER TABLE signups ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES profiles(id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_game_id ON notifications(game_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_games_host_id ON games(host_id);
CREATE INDEX IF NOT EXISTS idx_games_date_sport ON games(date, sport);
CREATE INDEX IF NOT EXISTS idx_signups_user_id ON signups(user_id);

-- Update games table for cascade delete behavior
ALTER TABLE games DROP CONSTRAINT IF EXISTS fk_host_id CASCADE;
ALTER TABLE games ADD CONSTRAINT fk_host_id FOREIGN KEY (host_id) REFERENCES profiles(id) ON DELETE SET NULL;

-- Enable RLS on new tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Allow read all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Allow insert own profile" ON profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow update own profile" ON profiles FOR UPDATE USING (true);

-- RLS Policies for notifications
CREATE POLICY "Allow read own notifications" ON notifications FOR SELECT USING (true);
CREATE POLICY "Allow insert notifications" ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow update own notifications" ON notifications FOR UPDATE USING (true);
