import { Header } from "@/components/header"
import { CreateGameForm } from "@/components/create-game-form"

export default function CreatePage() {
  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: "url(/sports-bg.jpg)",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8 sm:mb-10">
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Create a Game</h1>
            <p className="text-muted-foreground text-base sm:text-lg">
              Set up your game in seconds with our quick-select options
            </p>
          </div>
          <CreateGameForm />
        </div>
      </main>
    </div>
  )
}
