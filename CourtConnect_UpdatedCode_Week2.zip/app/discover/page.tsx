import { createClient } from "@/lib/supabase/server"
import { DiscoveryFilters } from "@/components/discovery-filters"
import { GameCard } from "@/components/game-card"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import type { Game } from "@/lib/types"

export const dynamic = "force-dynamic"

async function getGames(): Promise<Game[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("games")
    .select("*")
    .gte("date", new Date().toISOString().split("T")[0])
    .order("date", { ascending: true })
    .order("start_time", { ascending: true })

  if (error) {
    console.error("[v0] Error fetching games:", error)
    return []
  }

  return data || []
}

async function getSignupCounts(): Promise<Record<string, number>> {
  const supabase = await createClient()

  const { data, error } = await supabase.from("signups").select("game_id")

  if (error) {
    console.error("[v0] Error fetching signups:", error)
    return {}
  }

  const counts: Record<string, number> = {}
  data?.forEach((signup) => {
    counts[signup.game_id] = (counts[signup.game_id] || 0) + 1
  })

  return counts
}

export default async function DiscoverPage() {
  const [games, signupCounts] = await Promise.all([getGames(), getSignupCounts()])

  const gamesWithSpots = games.map((game) => ({
    ...game,
    spots_left: game.max_players - (signupCounts[game.id] || 0),
  }))

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8 sm:mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Discover Games</h1>
          <p className="text-muted-foreground text-base sm:text-lg">
            Find the perfect pickup game with advanced filters and search
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <DiscoveryFilters games={gamesWithSpots} />
          </div>

          {/* Games Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
              {gamesWithSpots.length > 0 ? (
                gamesWithSpots.map((game) => <GameCard key={game.id} game={game} />)
              ) : (
                <div className="col-span-full text-center py-16 px-4">
                  <div className="max-w-md mx-auto space-y-4">
                    <h3 className="text-xl font-semibold text-foreground">No games found</h3>
                    <p className="text-muted-foreground">Try adjusting your filters or create a new game!</p>
                    <Button asChild className="bg-primary hover:bg-primary/90">
                      <Link href="/create">Create Game</Link>
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
