import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import Link from "next/link"
import Image from "next/image"
import type { Profile } from "@/lib/types"

export const dynamic = "force-dynamic"

async function getProfile(id: string): Promise<Profile | null> {
  const supabase = await createClient()

  const { data, error } = await supabase.from("profiles").select("*").eq("id", id).single()

  if (error) {
    console.error("[v0] Error fetching profile:", error)
    return null
  }

  return data
}

async function getHostedGames(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("games")
    .select("id, sport, date, location")
    .eq("host_id", userId)
    .gte("date", new Date().toISOString().split("T")[0])
    .limit(5)

  if (error) {
    console.error("[v0] Error fetching hosted games:", error)
    return []
  }

  return data || []
}

async function getJoinedGames(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("signups")
    .select("game_id, games(id, sport, date, location)")
    .eq("user_id", userId)
    .limit(5)

  if (error) {
    console.error("[v0] Error fetching joined games:", error)
    return []
  }

  return data || []
}

export default async function ProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const profile = await getProfile(id)

  if (!profile) {
    return (
      <div className="min-h-screen relative">
        <div className="fixed inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
          <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
        </div>
        <Header />
        <main className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground">Profile Not Found</h1>
            <p className="text-muted-foreground mt-2">The user profile you're looking for doesn't exist.</p>
            <Link href="/">
              <Button className="mt-6">Back to Home</Button>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  const [hostedGames, joinedGames] = await Promise.all([getHostedGames(id), getJoinedGames(id)])

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
        <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8 sm:py-12">
        {/* Profile Header */}
        <Card className="mb-8 border-border/50 bg-card/50 backdrop-blur">
          <CardContent className="pt-6">
            <div className="flex items-start gap-6">
              {/* Avatar */}
              <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden flex-shrink-0 bg-gradient-to-br from-primary/20 to-accent/20 border border-border">
                <Image src="/placeholder-user.jpg" alt={profile.name} fill className="object-cover" />
              </div>

              {/* Profile Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 flex-wrap">
                  <h1 className="text-2xl sm:text-3xl font-bold text-foreground">{profile.name}</h1>
                  {profile.favorite_sport && (
                    <Badge className="bg-primary/20 text-primary border border-primary/30">
                      {profile.favorite_sport}
                    </Badge>
                  )}
                </div>

                {profile.bio && <p className="text-muted-foreground mt-2 line-clamp-2">{profile.bio}</p>}

                {/* Stats */}
                <div className="flex gap-6 mt-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Games Hosted</p>
                    <p className="text-xl font-bold text-primary">{profile.games_hosted}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Games Joined</p>
                    <p className="text-xl font-bold text-accent">{profile.games_joined}</p>
                  </div>
                </div>
              </div>

              {/* Edit Button */}
              <Link href={`/profile/${id}/edit`}>
                <Button className="bg-primary hover:bg-primary/90">Edit Profile</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Games Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Hosted Games */}
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardHeader>
              <CardTitle>Games Hosted</CardTitle>
              <CardDescription>Recent games you're hosting</CardDescription>
            </CardHeader>
            <CardContent>
              {hostedGames.length > 0 ? (
                <div className="space-y-3">
                  {hostedGames.map((game: any) => (
                    <Link key={game.id} href={`/game/${game.id}`}>
                      <div className="p-3 rounded-lg border border-border/50 hover:border-primary/50 hover:bg-card/80 transition-all cursor-pointer">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-foreground">{game.sport}</p>
                            <p className="text-sm text-muted-foreground">{game.location}</p>
                          </div>
                          <Badge variant="outline">{game.date}</Badge>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm">No hosted games yet</p>
              )}
            </CardContent>
          </Card>

          {/* Joined Games */}
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardHeader>
              <CardTitle>Games Joined</CardTitle>
              <CardDescription>Recent games you're joining</CardDescription>
            </CardHeader>
            <CardContent>
              {joinedGames.length > 0 ? (
                <div className="space-y-3">
                  {joinedGames.map((signup: any) => (
                    <Link key={signup.game_id} href={`/game/${signup.game_id}`}>
                      <div className="p-3 rounded-lg border border-border/50 hover:border-primary/50 hover:bg-card/80 transition-all cursor-pointer">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-foreground">{signup.games?.sport}</p>
                            <p className="text-sm text-muted-foreground">{signup.games?.location}</p>
                          </div>
                          <Badge variant="outline">{signup.games?.date}</Badge>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm">No joined games yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
