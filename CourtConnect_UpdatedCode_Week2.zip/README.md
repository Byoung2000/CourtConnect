# CourtConnect - Find Pickup Games

A modern, real-time sports game coordination platform built with Next.js, Supabase, and React. Discover and join pickup games in your community with an intuitive, mobile-first interface.

## Features

### Core Functionality
- **Game Discovery** - Browse available games filtered by sport, location, date, and availability
- **Game Creation** - Host pickup games with customizable details, location selection, and participant management
- **Real-time Updates** - Live player count, game status, and notifications using Supabase real-time subscriptions
- **Interactive Maps** - View game locations on an embedded map with directions to Google Maps
- **Game Chat** - Real-time lobby chat for players to coordinate before games start
- **Player Management** - Hosts can manage participants (remove/add players) and edit game details

### User Features
- **User Profiles** - Create profiles with bio, favorite sport, and game statistics
- **Game History** - View games hosted and joined with comprehensive stats
- **Notifications** - In-app notifications for new games, player joins, and game updates
- **Advanced Search** - Multi-filter search across sports, locations, dates, and availability
- **Favorites** - Save favorite sports for quick filtering

### Host Tools
- **Host Dashboard** - Centralized management of all hosted games
- **Player Management** - Remove participants, view signups, manage spots
- **Game Editing** - Update game details, max players, and notes in real-time
- **Deletion & Archive** - Permanently delete games (immediately removed from all users)
- **Host PIN** - Secure game management via PIN

## Tech Stack

- **Frontend**: Next.js 16 (App Router), React 19, TypeScript
- **Styling**: Tailwind CSS v4, shadcn/ui components
- **Database**: Supabase (PostgreSQL) with Row Level Security
- **Real-time**: Supabase real-time subscriptions (PostgreSQL LISTEN/NOTIFY)
- **Maps**: Leaflet + OpenStreetMap (free, no API key required)
- **Location Search**: Nominatim API (free, no API key required)
- **State Management**: React hooks + SWR for client-side data
- **UI Components**: shadcn/ui (50+ components)

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account (free tier available)

### Installation

1. **Clone the repository**
   \`\`\`bash
   git clone https://github.com/yourusername/courtconnect.git
   cd courtconnect
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**
   Create a `.env.local` file:
   \`\`\`env
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
   \`\`\`

4. **Set up database**
   - Create a new Supabase project
   - Run the migration scripts in `/scripts`:
     \`\`\`bash
     npm run migrate
     \`\`\`
   - This creates tables: `games`, `signups`, `messages`, `profiles`, `notifications`

5. **Start development server**
   \`\`\`bash
   npm run dev
   \`\`\`
   Open http://localhost:3000

## Project Structure

\`\`\`
courtconnect/
├── app/                        # Next.js app router
│   ├── page.tsx               # Home - games list
│   ├── create/                # Create game page
│   ├── game/[id]/             # Game detail/lobby page
│   ├── profile/[id]/          # User profile page
│   ├── discover/              # Advanced search page
│   ├── notifications/         # Notifications page
│   ├── host/dashboard/        # Host dashboard
│   └── layout.tsx             # Root layout
├── components/                 # React components
│   ├── ui/                    # shadcn/ui components
│   ├── game-card.tsx          # Game list item
│   ├── game-details.tsx       # Game lobby
│   ├── game-map.tsx           # Leaflet map display
│   ├── lobby-chat.tsx         # Real-time chat
│   ├── host-controls.tsx      # Host actions
│   ├── edit-profile-form.tsx  # Profile editor
│   ├── discovery-filters.tsx  # Advanced filters
│   └── ...
├── lib/
│   ├── supabase/              # Supabase clients (server/client)
│   ├── types.ts               # TypeScript interfaces
│   └── utils.ts               # Helper functions
├── scripts/                    # Database migrations
│   ├── 01_create_tables.sql
│   └── 02_create_profiles_and_notifications.sql
└── public/                     # Static assets
\`\`\`

## Database Schema

### Games Table
- `id` (UUID, primary)
- `sport` (text): Sport type
- `date` (date): Game date
- `start_time` (time): Start time
- `end_time` (time): End time
- `location` (text): Game location
- `max_players` (integer): Max participants
- `host_name` (text): Host name
- `host_pin` (text): 4-digit PIN for host management
- `note` (text): Additional details
- `created_at` (timestamp)

### Signups Table
- `id` (UUID, primary)
- `game_id` (UUID, foreign key)
- `player_name` (text): Participant name
- `created_at` (timestamp)

### Messages Table
- `id` (UUID, primary)
- `game_id` (UUID, foreign key)
- `sender_name` (text): Player name
- `message_text` (text): Message content
- `created_at` (timestamp)

### Profiles Table
- `id` (UUID, primary)
- `name` (text): User name
- `bio` (text): User bio
- `favorite_sport` (text): Preferred sport
- `games_hosted` (integer): Count of hosted games
- `games_joined` (integer): Count of joined games
- `created_at` (timestamp)
- `updated_at` (timestamp)

### Notifications Table
- `id` (UUID, primary)
- `user_id` (UUID, foreign key)
- `game_id` (UUID, foreign key)
- `type` (text): Notification type
- `title` (text): Notification title
- `message` (text): Notification message
- `read` (boolean): Read status
- `created_at` (timestamp)

## Key Features Deep Dive

### Real-time Game Deletion
When a host deletes a game:
1. All signups are cascaded deleted
2. All messages are deleted
3. Game record is deleted from database
4. Real-time subscriptions notify all connected users
5. Users on the game page are redirected to home
6. Game disappears from all game lists immediately

### Host Management
- Hosts identified via PIN stored in browser localStorage
- Can edit max players and game notes
- Can remove any participant except themselves
- Can see participant list with removal buttons
- Full game deletion with cascade cleanup

### Real-time Chat
- Supabase PostgreSQL LISTEN/NOTIFY for instant messaging
- No manual refresh needed - messages appear instantly
- Only visible to joined players
- Stored in database for history

### Notifications
- Track: new games, player joins, game updates, cancellations
- In-app notification bell with unread count
- Full notifications page with read/archive management
- Real-time subscription to notification changes

## Performance Optimizations

- **Code Splitting**: Dynamic imports for heavy components
- **Image Optimization**: Next.js Image component with lazy loading
- **Lazy Loading**: Components load on demand
- **Caching**: Server-side caching with revalidation
- **Minification**: Production builds automatically minified
- **CSS Purging**: Tailwind CSS unused CSS removal
- **Database Indexing**: Strategic indexes on frequently queried columns

## Mobile Optimization

- **Responsive Design**: Mobile-first approach using Tailwind breakpoints
- **Touch-friendly**: Large tap targets (min 44x44px)
- **Simplified Layout**: Stacked layouts on mobile, grid on desktop
- **Optimized Forms**: Full-width inputs and buttons on mobile
- **Viewport Meta**: Proper mobile viewport configuration
- **Performance**: Optimized for mobile network speeds

## Deployment

### Deploy to Vercel (Recommended)

1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically on push

\`\`\`bash
npm run build
npm start
\`\`\`

### Deploy to Other Platforms

**Docker:**
\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
\`\`\`

## Known Issues & Limitations

- Map display requires Leaflet CDN (dynamically loaded)
- Location search via Nominatim API (free tier rate limited)
- Real-time chat only works for players who joined the game
- Host PIN stored in localStorage (not persistent across devices)
- No user authentication system (uses localStorage + PIN)

## Future Enhancements

- User authentication system (email/social login)
- Image uploads for profiles and games
- Skill level filtering
- Player ratings and reviews
- Recurring games/series
- Payment integration for premium features
- Mobile app (React Native)
- Push notifications
- Email notifications
- Game scheduling calendar
- Elo/ranking system

## Troubleshooting

### Game not appearing on home page
- Refresh page (force: Ctrl+Shift+R on Chrome)
- Check if game date is in the past
- Verify Supabase connection in browser console

### Real-time updates not working
- Check browser console for errors
- Verify Supabase real-time is enabled
- Check network tab for failed requests
- Ensure user has proper permissions (RLS policies)

### Map not loading
- Check console for Leaflet errors
- Verify OpenStreetMap is accessible
- Try different browser/clear cache

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see LICENSE.md for details

## Support

For issues, questions, or suggestions:
- GitHub Issues: [Project Issues](https://github.com/yourusername/courtconnect/issues)
- Email: support@courtconnect.local
- Documentation: [Full Docs](./docs)

## Changelog

### Version 1.0.0 (Current)
- Initial release with core features
- Game creation and discovery
- Real-time chat and notifications
- Host management tools
- Map integration
- Mobile optimization
- Advanced search and filtering

---

Built with ❤️ for sports communities everywhere.
