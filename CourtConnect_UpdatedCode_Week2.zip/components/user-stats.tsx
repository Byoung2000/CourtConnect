import type { Profile } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"

interface UserStatsProps {
  profile: Profile
}

export function UserStats({ profile }: UserStatsProps) {
  return (
    <div className="grid grid-cols-3 gap-4">
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardContent className="pt-6 text-center">
          <p className="text-sm text-muted-foreground">Games Hosted</p>
          <p className="text-2xl font-bold text-primary mt-1">{profile.games_hosted}</p>
        </CardContent>
      </Card>
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardContent className="pt-6 text-center">
          <p className="text-sm text-muted-foreground">Games Joined</p>
          <p className="text-2xl font-bold text-accent mt-1">{profile.games_joined}</p>
        </CardContent>
      </Card>
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardContent className="pt-6 text-center">
          <p className="text-sm text-muted-foreground">Favorite Sport</p>
          <p className="text-sm font-semibold text-foreground mt-1 line-clamp-1">
            {profile.favorite_sport || "Not set"}
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
