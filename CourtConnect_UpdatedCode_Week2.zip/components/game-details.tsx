"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import type { Game, Signup } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calendar, Clock, MapPin, Users, Loader2, UserMinus, Shield, CheckCircle } from "lucide-react"
import { LobbyChat } from "@/components/lobby-chat"
import { HostControls } from "@/components/host-controls"
import { GameMap } from "@/components/game-map"
import { ExternalLink } from "lucide-react"

interface GameDetailsProps {
  game: Game
  signups: Signup[]
  spotsLeft: number
}

export function GameDetails({ game, signups: initialSignups, spotsLeft: initialSpotsLeft }: GameDetailsProps) {
  const router = useRouter()
  const [signups, setSignups] = useState(initialSignups)
  const [spotsLeft, setSpotsLeft] = useState(initialSpotsLeft)
  const [playerName, setPlayerName] = useState("")
  const [isJoining, setIsJoining] = useState(false)
  const [isLeaving, setIsLeaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [isHost, setIsHost] = useState(false)
  const [hasJoined, setHasJoined] = useState(false)

  useEffect(() => {
    // Check if user is the host
    const hostPin = localStorage.getItem(`host_pin_${game.id}`)
    if (hostPin === game.host_pin) {
      setIsHost(true)
    }

    // Check if user has already joined
    const storedPlayerName = localStorage.getItem(`player_name_${game.id}`)
    if (storedPlayerName) {
      setPlayerName(storedPlayerName)
      const userSignup = signups.find((s) => s.player_name === storedPlayerName)
      if (userSignup) {
        setHasJoined(true)
      }
    }
  }, [game.id, game.host_pin, signups])

  useEffect(() => {
    const supabase = createClient()

    const gameChannel = supabase
      .channel(`game_${game.id}`)
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "games",
          filter: `id=eq.${game.id}`,
        },
        () => {
          console.log("[v0] Game was deleted, redirecting to home")
          router.push("/")
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(gameChannel)
    }
  }, [game.id, router])

  // Real-time subscription for signups
  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(`game_${game.id}_signups`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "signups",
          filter: `game_id=eq.${game.id}`,
        },
        async () => {
          // Refetch signups when changes occur
          const { data } = await supabase
            .from("signups")
            .select("*")
            .eq("game_id", game.id)
            .order("created_at", { ascending: true })

          if (data) {
            setSignups(data)
            setSpotsLeft(game.max_players - data.length)
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [game.id, game.max_players])

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsJoining(true)
    setError(null)
    setSuccessMessage(null)

    if (!playerName.trim()) {
      setError("Please enter your name")
      setIsJoining(false)
      return
    }

    if (spotsLeft <= 0) {
      setError("This game is full")
      setIsJoining(false)
      return
    }

    // Check if name already exists
    if (signups.some((s) => s.player_name.toLowerCase() === playerName.trim().toLowerCase())) {
      setError("This name is already taken. Please choose a different name.")
      setIsJoining(false)
      return
    }

    try {
      const supabase = createClient()

      const { error: insertError } = await supabase.from("signups").insert({
        game_id: game.id,
        player_name: playerName.trim(),
      })

      if (insertError) throw insertError

      // Store player name in localStorage
      localStorage.setItem(`player_name_${game.id}`, playerName.trim())
      setHasJoined(true)
      setSuccessMessage("You've joined the game!")

      // Refresh the page to update signups
      router.refresh()
    } catch (err) {
      console.error("[v0] Error joining game:", err)
      setError(err instanceof Error ? err.message : "Failed to join game")
    } finally {
      setIsJoining(false)
    }
  }

  const handleLeave = async () => {
    setIsLeaving(true)
    setError(null)
    setSuccessMessage(null)

    try {
      const supabase = createClient()

      const { error: deleteError } = await supabase
        .from("signups")
        .delete()
        .eq("game_id", game.id)
        .eq("player_name", playerName)

      if (deleteError) throw deleteError

      // Remove player name from localStorage
      localStorage.removeItem(`player_name_${game.id}`)
      setHasJoined(false)
      setPlayerName("")

      // Refresh the page to update signups
      router.refresh()
    } catch (err) {
      console.error("[v0] Error leaving game:", err)
      setError(err instanceof Error ? err.message : "Failed to leave game")
    } finally {
      setIsLeaving(false)
    }
  }

  const handleRemovePlayer = async (signupPlayerName: string) => {
    if (!isHost) return

    try {
      const supabase = createClient()

      // Optimistically update UI
      setSignups((prev) => prev.filter((s) => s.player_name !== signupPlayerName))
      setSpotsLeft((prev) => prev + 1)

      const { error: deleteError } = await supabase
        .from("signups")
        .delete()
        .eq("game_id", game.id)
        .eq("player_name", signupPlayerName)

      if (deleteError) {
        throw deleteError
      }

      setSuccessMessage(`${signupPlayerName} has been removed from the game`)
    } catch (err) {
      console.error("[v0] Error removing player:", err)
      setError(err instanceof Error ? err.message : "Failed to remove player")
      // Revert optimistic update on error
      router.refresh()
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour % 12 || 12
    return `${displayHour}:${minutes} ${ampm}`
  }

  const isFull = spotsLeft <= 0
  const isGameStarted = new Date() > new Date(`${game.date}T${game.start_time}`)

  return (
    <div className="max-w-5xl mx-auto space-y-6 sm:space-y-8">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => router.push("/")}
        className="mb-4 text-muted-foreground hover:text-foreground"
      >
        ← Back to Games
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content - Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Game Info Card */}
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle className="text-3xl font-bold text-foreground mb-2">{game.sport}</CardTitle>
                  <div className="flex items-center gap-2 text-muted-foreground flex-wrap">
                    <Users className="w-4 h-4" />
                    <span>
                      Hosted by <span className="font-medium text-foreground">{game.host_name}</span>
                      {isHost && (
                        <Badge variant="secondary" className="ml-2 bg-primary/20 text-primary">
                          <Shield className="w-3 h-3 mr-1" />
                          You're the host
                        </Badge>
                      )}
                    </span>
                  </div>
                </div>
                <Badge
                  variant={isFull ? "destructive" : "default"}
                  className={
                    isFull
                      ? "bg-destructive text-destructive-foreground text-lg px-4 py-2"
                      : "bg-accent text-accent-foreground text-lg px-4 py-2"
                  }
                >
                  {isFull ? "Full" : `${spotsLeft} / ${game.max_players}`}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center gap-3 p-3 sm:p-4 rounded-lg bg-muted/50">
                  <Calendar className="w-6 h-6 text-primary flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-muted-foreground">Date</p>
                    <p className="font-semibold text-foreground text-sm">{formatDate(game.date)}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 sm:p-4 rounded-lg bg-muted/50">
                  <Clock className="w-6 h-6 text-secondary flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-muted-foreground">Time</p>
                    <p className="font-semibold text-foreground text-sm">
                      {formatTime(game.start_time)} - {formatTime(game.end_time)}
                    </p>
                  </div>
                </div>

                {/* Location Section with Map */}
                <div className="space-y-3">
                  {/* Location Card with Directions Link */}
                  <Card className="border-border bg-card">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-5 h-5 text-accent" />
                          Location & Directions
                        </div>
                        <Button variant="outline" size="sm" className="gap-2 text-xs bg-transparent" asChild>
                          <a
                            href={`https://www.google.com/maps/search/${encodeURIComponent(game.location)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="w-3 h-3" />
                            Open in Maps
                          </a>
                        </Button>
                      </CardTitle>
                    </CardHeader>
                  </Card>
                  {/* Interactive Map Display */}
                  <GameMap location={game.location} title="Game Location" />
                </div>
              </div>

              {game.note && (
                <div className="p-3 sm:p-4 rounded-lg bg-muted/50">
                  <p className="text-xs sm:text-sm text-muted-foreground mb-1">Additional Notes</p>
                  <p className="text-foreground text-sm">{game.note}</p>
                </div>
              )}

              {/* Game Map */}
              {/* Removed duplicate GameMap component */}
            </CardContent>
          </Card>

          {/* Players List */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-xl text-foreground">
                Players ({signups.length} / {game.max_players})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {signups.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No players yet. Be the first to join!</p>
              ) : (
                <div className="space-y-2">
                  {signups.map((signup, index) => (
                    <div
                      key={signup.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-semibold text-sm flex-shrink-0">
                          {index + 1}
                        </div>
                        <span className="font-medium text-foreground truncate">
                          {signup.player_name}
                          {signup.player_name === game.host_name && (
                            <Badge variant="secondary" className="ml-2 bg-primary/20 text-primary text-xs">
                              Host
                            </Badge>
                          )}
                          {signup.player_name === playerName && (
                            <Badge variant="secondary" className="ml-2 text-xs">
                              You
                            </Badge>
                          )}
                        </span>
                      </div>
                      {isHost && signup.player_name !== game.host_name && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemovePlayer(signup.player_name)}
                          className="text-destructive hover:text-destructive hover:bg-destructive/10 ml-2 flex-shrink-0"
                        >
                          <UserMinus className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Lobby Chat - Only visible to joined players */}
          {hasJoined && <LobbyChat gameId={game.id} playerName={playerName} />}
        </div>

        {/* Sidebar - Right Column */}
        <div className="lg:col-span-1 space-y-6">
          {/* Join/Leave Section */}
          {!isGameStarted && (
            <Card className="border-border bg-card sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg text-foreground">{hasJoined ? "You're In!" : "Join Game"}</CardTitle>
              </CardHeader>
              <CardContent>
                {successMessage && (
                  <Alert className="mb-4 border-accent/50 bg-accent/10">
                    <CheckCircle className="h-4 w-4 text-accent" />
                    <AlertDescription className="text-accent text-sm">{successMessage}</AlertDescription>
                  </Alert>
                )}

                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertDescription className="text-sm">{error}</AlertDescription>
                  </Alert>
                )}

                {!hasJoined ? (
                  <form onSubmit={handleJoin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="playerName" className="text-foreground text-sm">
                        Your Name
                      </Label>
                      <Input
                        id="playerName"
                        type="text"
                        placeholder="Enter your name"
                        value={playerName}
                        onChange={(e) => setPlayerName(e.target.value)}
                        className="bg-background h-10 text-sm"
                        disabled={isFull || isGameStarted}
                        required
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-sm h-10"
                      disabled={isJoining || isFull || isGameStarted}
                    >
                      {isJoining ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Joining...
                        </>
                      ) : isFull ? (
                        "Game is Full"
                      ) : (
                        "Join Game"
                      )}
                    </Button>
                  </form>
                ) : (
                  <div className="space-y-4">
                    <p className="text-muted-foreground text-sm">
                      Signed up as <span className="font-semibold text-foreground">{playerName}</span>
                    </p>
                    <Button
                      onClick={handleLeave}
                      variant="outline"
                      className="w-full border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground bg-transparent text-sm h-10"
                      disabled={isLeaving}
                    >
                      {isLeaving ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Leaving...
                        </>
                      ) : (
                        "Leave Game"
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Host Controls */}
          {isHost && <HostControls game={game} />}

          {/* External Link */}
          {!isGameStarted && (
            <Card className="border-border bg-card sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg text-foreground">External Link</CardTitle>
              </CardHeader>
              <CardContent>
                <a
                  href={game.external_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="w-6 h-6 text-primary" />
                  <span className="text-foreground text-sm">Join on External Platform</span>
                </a>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
