import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Game } from "@/lib/types"
import { Calendar, Clock, MapPin, Users } from "lucide-react"

interface GameCardProps {
  game: Game & { spots_left: number }
}

export function GameCard({ game }: GameCardProps) {
  const isFull = game.spots_left <= 0
  const isAlmostFull = game.spots_left <= 2 && game.spots_left > 0

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const gameDate = new Date(date)
    gameDate.setHours(0, 0, 0, 0)

    if (gameDate.getTime() === today.getTime()) {
      return "Today"
    }

    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    if (gameDate.getTime() === tomorrow.getTime()) {
      return "Tomorrow"
    }

    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour % 12 || 12
    return `${displayHour}:${minutes} ${ampm}`
  }

  return (
    <Link href={`/game/${game.id}`}>
      <Card className="hover:shadow-xl transition-all duration-200 hover:scale-[1.02] cursor-pointer border-border bg-card h-full group">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
              {game.sport}
            </CardTitle>
            <Badge
              variant={isFull ? "destructive" : isAlmostFull ? "secondary" : "default"}
              className={
                isFull
                  ? "bg-destructive text-destructive-foreground"
                  : isAlmostFull
                    ? "bg-amber-500 text-white"
                    : "bg-accent text-accent-foreground"
              }
            >
              {isFull ? "Full" : `${game.spots_left} spots`}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4 text-primary flex-shrink-0" />
            <span className="font-medium text-foreground">{formatDate(game.date)}</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4 text-secondary flex-shrink-0" />
            <span className="text-foreground">
              {formatTime(game.start_time)} - {formatTime(game.end_time)}
            </span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 text-accent flex-shrink-0" />
            <span className="text-foreground truncate">{game.location}</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2 border-t border-border">
            <Users className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">
              Hosted by <span className="font-medium text-foreground">{game.host_name}</span>
            </span>
          </div>

          {game.note && <p className="text-sm text-muted-foreground italic line-clamp-2 pt-2">{game.note}</p>}
        </CardContent>
      </Card>
    </Link>
  )
}
