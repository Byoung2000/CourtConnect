"use client"

import type React from "react"

import { useState } from "react"
import { Search, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import Link from "next/link"

interface SearchBarProps {
  onSearch?: (query: string) => void
  placeholder?: string
}

export function SearchBar({ onSearch, placeholder = "Search games..." }: SearchBarProps) {
  const [query, setQuery] = useState("")
  const [isOpen, setIsOpen] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setQuery(value)
    onSearch?.(value)
    setIsOpen(value.length > 0)
  }

  const handleClear = () => {
    setQuery("")
    setIsOpen(false)
    onSearch?.("")
  }

  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
      <Input
        value={query}
        onChange={handleChange}
        onFocus={() => query && setIsOpen(true)}
        onBlur={() => setTimeout(() => setIsOpen(false), 200)}
        placeholder={placeholder}
        className="pl-10 bg-background/50 border-border/50 h-11"
      />
      {query && (
        <button
          onClick={handleClear}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      )}

      {/* Quick Actions */}
      {isOpen && (
        <div className="absolute top-12 left-0 right-0 bg-card border border-border rounded-lg shadow-lg z-50">
          <Link href="/discover" className="block p-3 hover:bg-muted transition-colors">
            <p className="text-sm font-medium text-foreground">View all games</p>
            <p className="text-xs text-muted-foreground">Open advanced discovery</p>
          </Link>
        </div>
      )}
    </div>
  )
}
