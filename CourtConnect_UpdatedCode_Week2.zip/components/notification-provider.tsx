"use client"

import type React from "react"

import { useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import type { Notification } from "@/lib/types"

interface NotificationProviderProps {
  userId?: string
  children: React.ReactNode
}

export function NotificationProvider({ userId, children }: NotificationProviderProps) {
  const { toast } = useToast()

  useEffect(() => {
    if (!userId) return

    const supabase = createClient()
    const channel = supabase
      .channel(`user_${userId}_notifications`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const notification = payload.new as Notification

          // Show toast notification
          toast({
            title: notification.title,
            description: notification.message,
            duration: 5000,
          })
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId, toast])

  return <>{children}</>
}
