"use client"

import { useState, useMemo } from "react"
import { GameCard } from "@/components/game-card"
import type { Game } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Calendar, Dumbbell } from "lucide-react"

interface GamesListProps {
  games: (Game & { spots_left: number })[]
}

const SPORTS = ["All", "Basketball", "Soccer", "Volleyball", "Tennis", "Football", "Pickleball"] // Added Pickleball to sports filter
const TIME_FILTERS = ["All", "Today", "Tomorrow", "This Week"]

export function GamesList({ games }: GamesListProps) {
  const [sportFilter, setSportFilter] = useState("All")
  const [timeFilter, setTimeFilter] = useState("All")

  const filteredGames = useMemo(() => {
    let filtered = games

    // Sport filter
    if (sportFilter !== "All") {
      filtered = filtered.filter((game) => game.sport === sportFilter)
    }

    // Time filter
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    const weekEnd = new Date(today)
    weekEnd.setDate(weekEnd.getDate() + 7)

    if (timeFilter === "Today") {
      filtered = filtered.filter((game) => {
        const gameDate = new Date(game.date)
        gameDate.setHours(0, 0, 0, 0)
        return gameDate.getTime() === today.getTime()
      })
    } else if (timeFilter === "Tomorrow") {
      filtered = filtered.filter((game) => {
        const gameDate = new Date(game.date)
        gameDate.setHours(0, 0, 0, 0)
        return gameDate.getTime() === tomorrow.getTime()
      })
    } else if (timeFilter === "This Week") {
      filtered = filtered.filter((game) => {
        const gameDate = new Date(game.date)
        return gameDate >= today && gameDate <= weekEnd
      })
    }

    return filtered
  }, [games, sportFilter, timeFilter])

  return (
    <div className="space-y-6">
      {/* Filters Section */}
      <div className="space-y-4">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Dumbbell className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Sport</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {SPORTS.map((sport) => (
              <Button
                key={sport}
                variant={sportFilter === sport ? "default" : "outline"}
                size="sm"
                onClick={() => setSportFilter(sport)}
                className={
                  sportFilter === sport ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "hover:bg-accent"
                }
              >
                {sport}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-5 h-5 text-secondary" />
            <h2 className="text-lg font-semibold text-foreground">When</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {TIME_FILTERS.map((filter) => (
              <Button
                key={filter}
                variant={timeFilter === filter ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeFilter(filter)}
                className={
                  timeFilter === filter
                    ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                    : "hover:bg-accent"
                }
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Games Grid */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">
          {filteredGames.length === 0 ? "No Games Found" : "Available Games"}
        </h2>

        {filteredGames.length === 0 ? (
          <div className="text-center py-16 px-4">
            <div className="max-w-md mx-auto space-y-4">
              <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center">
                <Dumbbell className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground">No games yet</h3>
              <p className="text-muted-foreground">Be the first to create a game and get people playing!</p>
              <Button asChild className="bg-primary hover:bg-primary/90">
                <a href="/create">Create Game</a>
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredGames.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
