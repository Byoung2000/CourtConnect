"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import type { Game } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Shield, Trash2, Loader2, Info } from "lucide-react"

interface HostControlsProps {
  game: Game
}

export function HostControls({ game }: HostControlsProps) {
  const router = useRouter()
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleDeleteGame = async () => {
    setIsDeleting(true)
    setError(null)

    try {
      const supabase = createClient()

      // Delete the game (signups and messages will cascade delete)
      const { error: deleteError } = await supabase
        .from("games")
        .delete()
        .eq("id", game.id)
        .eq("host_pin", game.host_pin)

      if (deleteError) throw deleteError

      // Remove host PIN from localStorage
      localStorage.removeItem(`host_pin_${game.id}`)

      // Redirect to home
      router.push("/")
    } catch (err) {
      console.error("[v0] Error deleting game:", err)
      setError(err instanceof Error ? err.message : "Failed to delete game")
      setIsDeleting(false)
    }
  }

  return (
    <Card className="border-border bg-card border-primary/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          <CardTitle className="text-xl text-foreground">Host Controls</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            As the host, you can remove players from the game and delete the game entirely. Your host PIN is stored
            locally on this device.
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div className="p-3 rounded-lg bg-muted/50">
            <p className="text-sm text-muted-foreground mb-1">Host PIN</p>
            <p className="font-mono font-semibold text-foreground">{game.host_pin}</p>
            <p className="text-xs text-muted-foreground mt-1">Save this PIN to manage your game from other devices</p>
          </div>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full" disabled={isDeleting}>
                {isDeleting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Game
                  </>
                )}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete this game and remove all players. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteGame}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete Game
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  )
}
