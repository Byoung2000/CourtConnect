import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-primary/10">
              <Image src="/logo.jpg" alt="CourtConnect Logo" fill className="object-cover" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Court<span className="text-primary">Connect</span>
              </h1>
              <p className="text-xs text-muted-foreground">Find Your Game</p>
            </div>
          </Link>

          <Link href="/create">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
              Create Game
            </Button>
          </Link>
        </div>
      </div>
    </header>
  )
}
