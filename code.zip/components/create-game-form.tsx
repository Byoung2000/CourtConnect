"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar, Clock } from "lucide-react"

const SPORTS = ["Basketball", "Soccer", "Volleyball", "Tennis", "Football", "Pickleball"]
const QUICK_DATES = [
  { label: "Today", value: 0 },
  { label: "Tomorrow", value: 1 },
  { label: "In 2 Days", value: 2 },
  { label: "In 3 Days", value: 3 },
]

const QUICK_TIMES = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
]

const DURATION_OPTIONS = [
  { label: "30 min", minutes: 30 },
  { label: "1 hour", minutes: 60 },
  { label: "1.5 hours", minutes: 90 },
  { label: "2 hours", minutes: 120 },
]

export function CreateGameForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    sport: "",
    date: "",
    startTime: "",
    endTime: "",
    location: "",
    maxPlayers: "10",
    note: "",
    hostName: "",
  })

  const setQuickDuration = (minutes: number) => {
    if (!formData.startTime) return

    const [hours, mins] = formData.startTime.split(":").map(Number)
    const startDate = new Date()
    startDate.setHours(hours, mins, 0, 0)

    const endDate = new Date(startDate.getTime() + minutes * 60000)
    const endTime = `${String(endDate.getHours()).padStart(2, "0")}:${String(endDate.getMinutes()).padStart(2, "0")}`

    handleChange("endTime", endTime)
  }

  const setQuickDate = (daysFromNow: number) => {
    const date = new Date()
    date.setDate(date.getDate() + daysFromNow)
    const dateString = date.toISOString().split("T")[0]
    handleChange("date", dateString)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    if (
      !formData.sport ||
      !formData.date ||
      !formData.startTime ||
      !formData.endTime ||
      !formData.location ||
      !formData.hostName
    ) {
      setError("Please fill in all required fields")
      setIsLoading(false)
      return
    }

    const gameDate = new Date(formData.date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    if (gameDate < today) {
      setError("Game date must be today or in the future")
      setIsLoading(false)
      return
    }

    if (formData.startTime >= formData.endTime) {
      setError("End time must be after start time")
      setIsLoading(false)
      return
    }

    const maxPlayers = Number.parseInt(formData.maxPlayers)
    if (maxPlayers < 2) {
      setError("Maximum players must be at least 2")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()

      const hostPin = Math.floor(100000 + Math.random() * 900000).toString()

      const { data, error: insertError } = await supabase
        .from("games")
        .insert({
          sport: formData.sport,
          date: formData.date,
          start_time: formData.startTime,
          end_time: formData.endTime,
          location: formData.location,
          max_players: maxPlayers,
          note: formData.note || null,
          host_name: formData.hostName,
          host_pin: hostPin,
        })
        .select()
        .single()

      if (insertError) throw insertError

      if (data) {
        localStorage.setItem(`host_pin_${data.id}`, hostPin)
        router.push(`/game/${data.id}`)
      }
    } catch (err) {
      console.error("[v0] Error creating game:", err)
      setError(err instanceof Error ? err.message : "Failed to create game")
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const today = new Date().toISOString().split("T")[0]

  return (
    <Card className="border-border bg-card/95 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl text-foreground">Game Details</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="sport" className="text-foreground text-base font-semibold">
              Sport <span className="text-destructive">*</span>
            </Label>
            <Select value={formData.sport} onValueChange={(value) => handleChange("sport", value)}>
              <SelectTrigger id="sport" className="bg-background h-12 text-base">
                <SelectValue placeholder="Choose your sport" />
              </SelectTrigger>
              <SelectContent>
                {SPORTS.map((sport) => (
                  <SelectItem key={sport} value={sport} className="text-base">
                    {sport}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label className="text-foreground text-base font-semibold flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Date <span className="text-destructive">*</span>
            </Label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {QUICK_DATES.map((quickDate) => (
                <Button
                  key={quickDate.label}
                  type="button"
                  variant={
                    formData.date === new Date(Date.now() + quickDate.value * 86400000).toISOString().split("T")[0]
                      ? "default"
                      : "outline"
                  }
                  onClick={() => setQuickDate(quickDate.value)}
                  className="h-10"
                >
                  {quickDate.label}
                </Button>
              ))}
            </div>
            <Input
              id="date"
              type="date"
              min={today}
              value={formData.date}
              onChange={(e) => handleChange("date", e.target.value)}
              className="bg-background h-12"
              required
            />
          </div>

          <div className="space-y-3">
            <Label className="text-foreground text-base font-semibold flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Start Time <span className="text-destructive">*</span>
            </Label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {QUICK_TIMES.map((time) => (
                <Button
                  key={time}
                  type="button"
                  variant={formData.startTime === time ? "default" : "outline"}
                  onClick={() => handleChange("startTime", time)}
                  className="h-10 text-sm"
                >
                  {time}
                </Button>
              ))}
            </div>
            <Input
              id="startTime"
              type="time"
              value={formData.startTime}
              onChange={(e) => handleChange("startTime", e.target.value)}
              className="bg-background h-12"
              required
            />
          </div>

          <div className="space-y-3">
            <Label className="text-foreground text-base font-semibold">
              Duration <span className="text-destructive">*</span>
            </Label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DURATION_OPTIONS.map((duration) => (
                <Button
                  key={duration.label}
                  type="button"
                  variant="outline"
                  onClick={() => setQuickDuration(duration.minutes)}
                  disabled={!formData.startTime}
                  className="h-10"
                >
                  {duration.label}
                </Button>
              ))}
            </div>
            <Input
              id="endTime"
              type="time"
              value={formData.endTime}
              onChange={(e) => handleChange("endTime", e.target.value)}
              className="bg-background h-12"
              placeholder="Or set custom end time"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location" className="text-foreground text-base font-semibold">
                Location <span className="text-destructive">*</span>
              </Label>
              <Input
                id="location"
                type="text"
                placeholder="e.g., Main Gym, Outdoor Court A, Recreation Center"
                value={formData.location}
                onChange={(e) => handleChange("location", e.target.value)}
                className="bg-background h-12 text-base"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxPlayers" className="text-foreground text-base font-semibold">
                Max Players <span className="text-destructive">*</span>
              </Label>
              <Input
                id="maxPlayers"
                type="number"
                min="2"
                max="50"
                value={formData.maxPlayers}
                onChange={(e) => handleChange("maxPlayers", e.target.value)}
                className="bg-background h-12 text-base"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="hostName" className="text-foreground text-base font-semibold">
              Your Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="hostName"
              type="text"
              placeholder="Enter your name"
              value={formData.hostName}
              onChange={(e) => handleChange("hostName", e.target.value)}
              className="bg-background h-12 text-base"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="note" className="text-foreground text-base font-semibold">
              Additional Notes (Optional)
            </Label>
            <Textarea
              id="note"
              placeholder="Any details players should know? (skill level, what to bring, etc.)"
              value={formData.note}
              onChange={(e) => handleChange("note", e.target.value)}
              className="bg-background min-h-[100px] text-base"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push("/")}
              className="flex-1 h-12"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 h-12 bg-primary hover:bg-primary/90 text-primary-foreground text-base font-semibold"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Game"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
