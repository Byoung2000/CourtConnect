import { createClient } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { GameDetails } from "@/components/game-details"
import { notFound } from "next/navigation"
import type { Game, Signup } from "@/lib/types"

export const dynamic = "force-dynamic"

async function getGame(id: string): Promise<Game | null> {
  const supabase = await createClient()

  const { data, error } = await supabase.from("games").select("*").eq("id", id).single()

  if (error) {
    console.error("[v0] Error fetching game:", error)
    return null
  }

  return data
}

async function getSignups(gameId: string): Promise<Signup[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("signups")
    .select("*")
    .eq("game_id", gameId)
    .order("created_at", { ascending: true })

  if (error) {
    console.error("[v0] Error fetching signups:", error)
    return []
  }

  return data || []
}

export default async function GamePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const [game, signups] = await Promise.all([getGame(id), getSignups(id)])

  if (!game) {
    notFound()
  }

  const spotsLeft = game.max_players - signups.length

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <GameDetails game={game} signups={signups} spotsLeft={spotsLeft} />
      </main>
    </div>
  )
}
