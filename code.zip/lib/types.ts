export interface Game {
  id: string
  sport: string
  date: string
  start_time: string
  end_time: string
  location: string
  max_players: number
  note?: string
  host_name: string
  host_pin: string
  created_at: string
}

export interface Signup {
  id: string
  game_id: string
  player_name: string
  created_at: string
}

export interface Message {
  id: string
  game_id: string
  sender_name: string
  message_text: string
  created_at: string
}

export interface GameWithSignups extends Game {
  signups: Signup[]
  spots_left: number
}
